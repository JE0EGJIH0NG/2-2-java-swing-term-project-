package Game;

public class MainProgram {
	public static void main(String args[]) {	
		Main m = new Main();
	
	}

}
